# Programadores do Futuro

Esse projeto é inspirado na loja de roupa chamada "CLASS" desenvolvido com **HTML**, **CSS** e **JavaScript**.

## 👥 Colaboradores

Enzo Souza (https://github.com/letisgou) **(CSS)** <br>
Gustavo Duarte (https://github.com/gusttvodev) **(HTML e CSS)** <br>
Vitor (https://github.com/Pererinha04) **(CSS e JavaScript)** <br>

## 🚀 Tecnologias Utilizadas

- **HTML** - para a estruturação do conteúdo. <br>
- **CSS** para estilização visual. <br>
- **JavaScript** para implementar a funcionalidade. <br>