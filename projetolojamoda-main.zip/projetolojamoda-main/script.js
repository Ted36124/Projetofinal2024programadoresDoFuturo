function erro(){
    alert("produto indisponivel")
}