function funcao1()
{
    alert("infelizmente esgotou😔")
}