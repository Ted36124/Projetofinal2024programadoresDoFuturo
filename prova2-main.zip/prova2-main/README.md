
# programadores do Futuro

 [ Colaboradores do Projeto]

 - Alexandre
 - Caio
 - João Carlos
 
 site base para o nosso projeto!!

      [https://www.classixoficial.com/classix?assortment=lowest_price].

      [    https://www.gsuplementos.com.br/?gad_source=1&gclid=Cj0KCQiAi_G5BhDXARIsAN5SX7rOMbTzEOtCUsoDo6GnKfvUaBx_WMNnSDrAcNmUFK5mN4Q3MtfC_aEaAk3VEALw_wcB]                                                          
# Começo 
  -[x]logo da empresa;
  -[x]nome da empresa;(men style)
  -[x]contato da empresa;
        -[x] número de telefone
        -[x] Cnpj  
  -[ ]redes sociais;
## Estrutura base do site 
-[ ] Parte do HTML
-[ ] parte do CSS
-[ ] parte do js( JavaScript )