function funcao1()
{
alert("Produto esgotado!");
}