const nome = prompt("para começarmos, nos fale o seu nome");
document.write("é um prazer atender você " , nome , 
    " segue abaixo o nosso cárdapio, esperamos que goste");
