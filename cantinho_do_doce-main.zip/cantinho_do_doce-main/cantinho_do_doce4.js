let sim = prompt("você gosta de Natal")
if(sim=='sim'){
    alert("que maravilha, então tenho certeza que você vai gostar do nosso combo especial de natal")
    
}
else{
    alert("poxa, que pena, mas espero que você goste das nossas outras promoções")
}