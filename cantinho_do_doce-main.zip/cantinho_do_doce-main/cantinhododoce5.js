const sim = prompt("gostou do nosso atendimento?")
if (sim== 'sim') {
    alert ("que bom que voce gostou espero que volte sempre!")
}
 